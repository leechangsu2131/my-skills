/**
 * 파일을 Base64로 인코딩
 * @param file 파일 객체
 * @returns Base64 문자열
 */
export async function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1] || "");
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/**
 * 파일을 ArrayBuffer로 변환
 * @param file 파일 객체
 * @returns ArrayBuffer
 */
export async function fileToArrayBuffer(file: File): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      resolve(reader.result as ArrayBuffer);
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

/**
 * 파일 크기 포맷팅
 * @param bytes 바이트 수
 * @returns 포맷된 문자열
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
}

/**
 * 파일 유효성 검사
 * @param file 파일 객체
 * @param maxSizeMB 최대 파일 크기 (MB)
 * @param allowedTypes 허용된 MIME 타입
 * @returns 유효성 검사 결과
 */
export function validateFile(
  file: File,
  maxSizeMB: number = 50,
  allowedTypes: string[] = ["application/pdf"]
): { valid: boolean; error?: string } {
  if (!file) {
    return { valid: false, error: "파일을 선택해주세요." };
  }

  if (file.size > maxSizeMB * 1024 * 1024) {
    return { valid: false, error: `파일 크기는 ${maxSizeMB}MB 이하여야 합니다.` };
  }

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: `허용되지 않는 파일 형식입니다. (${allowedTypes.join(", ")})` };
  }

  return { valid: true };
}
