import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import type { ExamResult } from '@/types/exam';

export async function annotatePdf(result: ExamResult): Promise<Uint8Array> {
  const fileBytes = await result.pdfFile.arrayBuffer();
  const pdfDoc = await PDFDocument.load(fileBytes);
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  const pages = pdfDoc.getPages();
  const lastPage = pages[pages.length - 1];
  const { width, height } = lastPage.getSize();

  // Add a results summary box at the bottom of the last page
  const boxHeight = 120 + result.results.length * 14;
  const boxY = 20;
  const boxX = 20;
  const boxWidth = width - 40;

  // Semi-transparent background
  lastPage.drawRectangle({
    x: boxX,
    y: boxY,
    width: boxWidth,
    height: Math.min(boxHeight, height - 40),
    color: rgb(1, 1, 1),
    opacity: 0.9,
    borderColor: rgb(0.2, 0.4, 0.8),
    borderWidth: 1.5,
  });

  let y = boxY + Math.min(boxHeight, height - 40) - 25;

  // Title
  lastPage.drawText('GRADING RESULT', {
    x: boxX + 15,
    y,
    size: 14,
    font: fontBold,
    color: rgb(0.15, 0.3, 0.7),
  });
  y -= 18;

  // Score summary
  const scorePercent = ((result.totalScore / result.maxScore) * 100).toFixed(1);
  lastPage.drawText(
    `Score: ${result.totalScore}/${result.maxScore} (${scorePercent}%)  |  Correct: ${result.correctCount}/${result.totalQuestions}`,
    { x: boxX + 15, y, size: 10, font: fontBold, color: rgb(0.1, 0.1, 0.1) }
  );
  y -= 16;

  // Separator line
  lastPage.drawLine({
    start: { x: boxX + 10, y },
    end: { x: boxX + boxWidth - 10, y },
    thickness: 0.5,
    color: rgb(0.7, 0.7, 0.7),
  });
  y -= 14;

  // Individual results
  for (const r of result.results) {
    if (y < boxY + 10) break;
    const mark = r.isCorrect ? 'O' : 'X';
    const markColor = r.isCorrect ? rgb(0.1, 0.7, 0.2) : rgb(0.9, 0.15, 0.15);

    lastPage.drawText(mark, {
      x: boxX + 15,
      y,
      size: 10,
      font: fontBold,
      color: markColor,
    });

    lastPage.drawText(
      `Q${r.questionNumber}: ${r.studentAnswer || '-'}  (Ans: ${r.correctAnswer})  [${r.earnedPoints}/${r.points}]`,
      { x: boxX + 35, y, size: 8, font, color: rgb(0.2, 0.2, 0.2) }
    );
    y -= 13;
  }

  // Analysis content if available
  if (result.analysisContent && y > boxY + 30) {
    y -= 5;
    lastPage.drawLine({
      start: { x: boxX + 10, y },
      end: { x: boxX + boxWidth - 10, y },
      thickness: 0.5,
      color: rgb(0.7, 0.7, 0.7),
    });
    y -= 14;
    lastPage.drawText('Analysis:', {
      x: boxX + 15, y, size: 9, font: fontBold, color: rgb(0.3, 0.3, 0.6),
    });
    y -= 12;
    // Truncate long analysis
    const lines = result.analysisContent.split('\n').slice(0, 8);
    for (const line of lines) {
      if (y < boxY + 10) break;
      lastPage.drawText(line.slice(0, 100), {
        x: boxX + 15, y, size: 7, font, color: rgb(0.3, 0.3, 0.3),
      });
      y -= 10;
    }
  }

  return pdfDoc.save();
}
